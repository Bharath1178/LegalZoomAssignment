import { LightningElement, wire, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import modal from "@salesforce/resourceUrl/custommodal";
import { CloseActionScreenEvent } from "lightning/actions";
import { loadStyle } from "lightning/platformResourceLoader";
import convertContactToLead from '@salesforce/apex/ContactToLead.convertContactToLead';
export default class LwcUnconvertLead extends NavigationMixin(LightningElement) {
    @api recordId;
    leadContactDetails;
    connectedCallback() {
        //loadStyle(this, modal);  
        setTimeout(() => {
            this.invokeApexMethods();
        }, 5);

    }
    async invokeApexMethods() {
        try {
            const result = await convertContactToLead({
                contactId: this.recordId
            });
            console.log('Method result: ' + JSON.stringify(result));
            this.leadContactDetails = result;
            setTimeout(() => {
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: result.leadRec.Id,
                        objectApiName: 'Lead',
                        actionName: 'view'
                    },
                });
            }, 5);
        } catch (error) {
            console.log(error);
        } finally {
            console.log('Finally Block');
        }
    }
}